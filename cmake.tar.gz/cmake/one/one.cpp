#include <one/one.h>

int get_int_value()
{
    return 100;
}
