int get_int_value();
